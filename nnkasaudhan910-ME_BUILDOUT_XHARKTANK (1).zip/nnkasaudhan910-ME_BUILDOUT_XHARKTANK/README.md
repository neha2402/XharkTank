## XharkTank
 Xharks are self-made multi-millionaires judge the business concepts and products pitched and then decide whether to invest their own money to help market and mentor each contestant.XharkTank is a platform where we connect new energetic entrepreneurs to investors. Here, entrepreneurs can post their idea with their asked amount and exchangeable equity and investors can make a counteroffer.
 

 ## Tech Stack

Server: Node JS, Express JS

Database: Mongo DB(Atlas)

## Setup
To run API locally, make sure to create a ```.env ```file and copy variables from ```example.env``` and give them valid values as well

Clone the project

Go to the project directory

### Running backend
```
npm install
node server.js
run the test cases
```
 ### API Offers endpoints for

 - [x] Post a pitch
 - [x] Make a counter offer for a pitch
 - [x] All the pitches in the reverse chronological order
 - [x] Fetch a single Pitch