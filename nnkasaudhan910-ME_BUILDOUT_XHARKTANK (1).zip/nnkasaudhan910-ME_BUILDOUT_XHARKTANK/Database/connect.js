import mongoose from 'mongoose';
import colors from 'colors';
const  URL="mongodb+srv://Nancy:PGPfjjHyEc6hbLeX@cluster0.id1ddp6.mongodb.net/?retryWrites=true&w=majority"
const connectDataBase = async () => {
  try {
    const conn = await mongoose.connect(URL, {
      useNewUrlParser: true,
      useUnifiedTopology: true,
    });

    console.log(`MongoDB Connected: ${conn.connection.host}`.cyan.underline);
  } catch (error) {
    console.log(`Error: ${error.message}`.red.bold);
    process.exit();
  }
};

mongoose.set('toJSON', {
  virtuals: true,
  transform: (doc, converted) => {
    delete converted._id;
    delete converted.__v;
    delete converted.createdAt;
    delete converted.updatedAt;
  }
});

export default connectDataBase;